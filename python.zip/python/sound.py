#play a sound on windows
import winsound
winsound.PlaySound('LoopyMusic.wav', winsound.SND_FILENAME)
 
