from mystack import *#import from custom module
print "MyStack version :",version
s=Stack() # create a stack
goodHabits=Stack() # create another stack
s.push(1)
s.push(2)
s.push(3)
s.push(4)
s.pop()
s.pop()
s.pop()
s.pop()

goodHabits.push("Drink lot of water")
goodHabits.push("Have your dinner early")
goodHabits.push("Eat more salads")
goodHabits.push("When you feel like having tea/cofee, take a walk")
goodHabits.pop()
goodHabits.pop()
goodHabits.pop()
goodHabits.pop()