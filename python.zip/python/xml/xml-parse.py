f=open('sample.xml')
from xml.etree import ElementTree
tree=ElementTree.parse(f)
for node in tree.iter():
    print node.tag,node.attrib,node.text