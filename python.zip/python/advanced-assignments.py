#Advanced assignments
a,b=list
a,b=tupple
a,b=dict
#smart way to swap variables.
