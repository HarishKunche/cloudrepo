# getting started with if


aura = 2
if aura < 2.5:
   print "you are not healthy"

# if else   
   
aura = 2

if aura <= 1:
    print( "You're dead!" )
else:
    print( "You're alive!" )

input( "\nPress Enter to exit..." )




# if elif else

aura = 2

if aura <= 1:
    print "You're dead!" 
elif aura > 3:
    print "You're spiritual!" 
else:
    print "You're alive!" 





