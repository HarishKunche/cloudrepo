#for loop



for i in range(5):
    print i,
	
	

weapons = [ "Arrow", "Mace", "Spear", "Sword" ]


for x in weapons:
    print x 

	
	
	
#converting the below c for loop into python
for (i=65;i<=345;i=i+5)
{
printf("%d", i*i);
}





for i in range(65,346,5):
	print i*i




	
for (i=365;i>=45;i=i-5)
{
print i*i;
}	



for i in range(365,44,-5):
	print i*i
