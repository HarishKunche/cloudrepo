
import wx
ex = wx.App()
menubar = wx.MenuBar()
ex.Show()
ex.MainLoop()   
  