#parse an xml document
from xml.etree import ElementTree

document = ElementTree.parse( 'membership.xml' )

#document will have an object that is not exactly a node in the XML structure,
#but it provides a handful of functions to consume the contents of the element
#hierarchy parsed from the file. Which way you choose is largely a matter
#of taste and probably influenced by the task at hand.
#The following are examples:

users = document.find( 'users')
#is equivalent to:

membership = document.getroot()
users = membership.find( 'users' )

#Finding specific elements

#XML is a hierarchical structure. Depending on what you do,
#you may want to enforce certain hierarchy of elements when consuming
#the contents of the file. For example, we know that the membership.xml
#file expects users to be defined like membership -> users -> user.
#You can quickly get all the user nodes by doing this:

for user in document.findall( 'users/user' ):
    print user.attrib[ 'name' ]

#Likewise, you can quickly get all the groups by doing this:

for group in document.findall( 'groups/group' ):
    print group.attrib[ 'name' ]
Iterating elements

#Even after finding specific elements or entry points in the hierarchy,
#you will normally need to iterate the children of a given node.
#This can be done like this:

for group in document.findall( 'groups/group' ):
    print 'Group:', group.attrib[ 'name' ]
    print 'Users:'
    for node in group.getchildren():
        if node.tag == 'user':
            print '-', node.attrib[ 'name' ]
#Other times, you may need to visit every single element in the hierarchy
#from any given starting point. There are two ways of doing it,
#one includes the starting element in the iteration, the other only its children.
#Subtle, but important difference, i.e.:

#Iterate nodes including starting point:

users = document.find( 'users' )
for node in users.getiterator():
    print node.tag, node.attrib, node.text, node.tail
#Produces this output:

#users {} None None
#user {'name': 'john'} None None
#user {'name': 'charles'} None None
#user {'name': 'peter'} None None
#Iterate only the children:

users = document.find( 'users' )
for node in users.getchildren():
    print node.tag, node.attrib, node.text, node.tail
#Produces this output:

#user {'name': 'john'} None None
#user {'name': 'charles'} None None
#user {'name': 'peter'} None None